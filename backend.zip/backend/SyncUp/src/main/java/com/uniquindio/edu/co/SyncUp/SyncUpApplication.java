package com.uniquindio.edu.co.SyncUp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SyncUpApplication {

	public static void main(String[] args) {
		SpringApplication.run(SyncUpApplication.class, args);
	}

}
