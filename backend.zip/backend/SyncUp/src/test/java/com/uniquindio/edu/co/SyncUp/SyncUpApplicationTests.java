package com.uniquindio.edu.co.SyncUp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SyncUpApplicationTests {

	@Test
	void contextLoads() {
	}

}
