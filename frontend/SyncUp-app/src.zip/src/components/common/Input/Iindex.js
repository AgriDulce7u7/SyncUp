export { default } from './Input';
export { default as Input } from './Input';